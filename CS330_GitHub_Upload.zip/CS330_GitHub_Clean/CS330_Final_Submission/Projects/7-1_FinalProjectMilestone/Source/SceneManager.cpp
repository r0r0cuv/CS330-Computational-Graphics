///////////////////////////////////////////////////////////////////////////////
// shadermanager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();

	// Initialize the texture collection
	for (int i = 0; i < 16; i++)
	{
		m_textureIDs[i].tag = "/0";
		m_textureIDs[i].ID = -1;
	}

	// No textures have been loaded yet
	m_loadedTextures = 0;
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}

}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationX * rotationY * rotationZ * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
 /***********************************************************
  *  FindTextureSlot()
  *
  *  Finds the OpenGL texture slot associated with a
  *  texture tag.
  ***********************************************************/


void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
			m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}


/***********************************************************
 *  DefineObjectMaterials()
 *
 *  Defines the material properties used for the desk lamp
 *  scene so the objects respond correctly to lighting.
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	OBJECT_MATERIAL material;

	// Material for the wooden floor plane
	material.ambientColor = glm::vec3(0.20f, 0.18f, 0.15f);
	material.ambientStrength = 0.20f;
	material.diffuseColor = glm::vec3(0.45f, 0.45f, 0.45f);
	material.specularColor = glm::vec3(0.10f, 0.10f, 0.10f);
	material.shininess = 8.0f;
	material.tag = "floorMaterial";

	m_objectMaterials.push_back(material);

	// Material for the metallic parts of the lamp
	material.ambientColor = glm::vec3(0.20f, 0.20f, 0.20f);
	material.ambientStrength = 0.20f;
	material.diffuseColor = glm::vec3(0.45f, 0.45f, 0.45f);
	material.specularColor = glm::vec3(0.50f, 0.50f, 0.50f);
	material.shininess = 32.0f;
	material.tag = "metalMaterial";

	m_objectMaterials.push_back(material);

	// Material for the gold lamp shade
	material.ambientColor = glm::vec3(0.30f, 0.22f, 0.08f);
	material.ambientStrength = 0.20f;
	material.diffuseColor = glm::vec3(0.50f, 0.42f, 0.20f);
	material.specularColor = glm::vec3(0.30f, 0.25f, 0.15f);
	material.shininess = 16.0f;
	material.tag = "shadeMaterial";

	m_objectMaterials.push_back(material);
}

/***********************************************************
 *  SetupSceneLights()
 *
 *  Configures two light sources for the desk lamp scene.
 *  A warm primary light illuminates the lamp and desk,
 *  while a secondary light prevents excessive shadows.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	// Primary warm light positioned near the lamp shade
	m_pShaderManager->setVec3Value(
		"lightSources[0].position", 2.0f, 8.0f, 3.0f);
	m_pShaderManager->setVec3Value(
		"lightSources[0].ambientColor", 0.08f, 0.06f, 0.04f);
	m_pShaderManager->setVec3Value(
		"lightSources[0].diffuseColor", 0.45f, 0.35f, 0.22f);
	m_pShaderManager->setVec3Value(
		"lightSources[0].specularColor", 0.35f, 0.30f, 0.20f);
	m_pShaderManager->setFloatValue(
		"lightSources[0].focalStrength", 32.0f);
	m_pShaderManager->setFloatValue(
		"lightSources[0].specularIntensity", 0.35f);

	// Secondary white fill light illuminates the workspace
	m_pShaderManager->setVec3Value(
		"lightSources[1].position", -4.0f, 7.0f, 5.0f);

	m_pShaderManager->setVec3Value(
		"lightSources[1].ambientColor", 0.12f, 0.12f, 0.12f);

	m_pShaderManager->setVec3Value(
		"lightSources[1].diffuseColor", 0.45f, 0.45f, 0.45f);

	m_pShaderManager->setVec3Value(
		"lightSources[1].specularColor", 0.25f, 0.25f, 0.25f);

	m_pShaderManager->setFloatValue(
		"lightSources[1].focalStrength", 32.0f);

	m_pShaderManager->setFloatValue(
		"lightSources[1].specularIntensity", 0.25f);

	// Enable Phong lighting
	m_pShaderManager->setBoolValue("bUseLighting", true);
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/


/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
 /***********************************************************
  *  LoadSceneTextures()
  *
  *  Loads the texture images used for the desk lamp scene
  *  and binds them to OpenGL texture slots.
  ***********************************************************/
void SceneManager::LoadSceneTextures()
{
	bool bReturn = false;

	// Wood texture for the floor plane
	bReturn = CreateGLTexture(
		"../../Utilities/textures/rusticwood.jpg",
		"floor");

	// Stainless steel texture for the lamp base and supports
	bReturn = CreateGLTexture(
		"../../Utilities/textures/stainless.jpg",
		"lampMetal");

	// Gold texture for the lamp shade
	bReturn = CreateGLTexture(
		"../../Utilities/textures/gold-seamless-texture.jpg",
		"lampShade");

	// Bind all loaded textures to OpenGL texture slots
	BindGLTextures();
}

void SceneManager::PrepareScene()
{
	// Load and bind the textures used in this scene
	LoadSceneTextures();

	// Define material properties for lighting
	DefineObjectMaterials();

	// Configure the scene lighting
	SetupSceneLights();

	// Load the meshes needed to construct the desk lamp
	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadConeMesh();
	m_basicMeshes->LoadSphereMesh();
	m_basicMeshes->LoadBoxMesh();
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by 
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(20.0f, 1.0f, 10.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Apply the floor material so it reflects the scene lighting
	SetShaderMaterial("floorMaterial");

	// Apply the rustic wood texture to the floor
	SetShaderTexture("floor");

	// Tile the wood texture across the large floor plane
	SetTextureUVScale(5.0f, 5.0f);

	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();
	/****************************************************************/
	/******************************************************************
 /******************************************************************
 * LAMP BASE
 * A short, wide cylinder forms the base of the desk lamp.
 ******************************************************************/
	scaleXYZ = glm::vec3(1.3f, 0.25f, 1.3f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(0.0f, 0.125f, 0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Apply reflective metal material to the lamp base
	SetShaderMaterial("metalMaterial");

	// Apply stainless steel texture to the lamp base
	SetShaderTexture("lampMetal");
	SetTextureUVScale(1.0f, 1.0f);

	m_basicMeshes->DrawCylinderMesh();

	/******************************************************************
 * COFFEE MUG HANDLE - TOP CONNECTION
 ******************************************************************/
	scaleXYZ = glm::vec3(0.45f, 0.10f, 0.12f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(-1.95f, 0.70f, 1.8f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderMaterial("metalMaterial");
	SetShaderColor(0.85f, 0.80f, 0.70f, 1.0f);

	m_basicMeshes->DrawBoxMesh();

	/******************************************************************
	 * COFFEE MUG HANDLE - OUTER GRIP
	 ******************************************************************/
	scaleXYZ = glm::vec3(0.12f, 0.45f, 0.12f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(-1.75f, 0.48f, 1.8f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderMaterial("metalMaterial");
	SetShaderColor(0.85f, 0.80f, 0.70f, 1.0f);

	m_basicMeshes->DrawBoxMesh();

	/******************************************************************
	 * COFFEE MUG HANDLE - BOTTOM CONNECTION
	 ******************************************************************/
	scaleXYZ = glm::vec3(0.45f, 0.10f, 0.12f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(-1.95f, 0.25f, 1.8f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderMaterial("metalMaterial");
	SetShaderColor(0.85f, 0.80f, 0.70f, 1.0f);

	m_basicMeshes->DrawBoxMesh();


	/******************************************************************
	 * VERTICAL LAMP SUPPORT
	 * A narrow cylinder forms the main upright support.
	 ******************************************************************/
	scaleXYZ = glm::vec3(0.25f, 3.0f, 0.25f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(0.0f, 0.25f, 0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Apply metal material to the vertical lamp support
	SetShaderMaterial("metalMaterial");

	// Apply stainless steel texture to the vertical lamp support
	SetShaderTexture("lampMetal");
	SetTextureUVScale(1.0f, 1.0f);

	m_basicMeshes->DrawCylinderMesh();


	/******************************************************************
	 * LAMP JOINT
	 * A sphere connects the vertical support to the angled arm.
	 ******************************************************************/
	scaleXYZ = glm::vec3(0.45f, 0.45f, 0.45f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(0.0f, 3.55f, 0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Apply metal material to the lamp joint
	SetShaderMaterial("metalMaterial");

	// Apply stainless steel texture to the lamp joint
	SetShaderTexture("lampMetal");
	SetTextureUVScale(1.0f, 1.0f);


	m_basicMeshes->DrawSphereMesh();


	/******************************************************************
	 * ANGLED LAMP ARM
	 * Rotate the cylinder to create the angled upper support.
	 ******************************************************************/
	scaleXYZ = glm::vec3(0.22f, 1.8f, 0.22f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = -40.0f;

	positionXYZ = glm::vec3(0.45f, 3.80f, 0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Apply metal material to the angled lamp arm
	SetShaderMaterial("metalMaterial");


	// Apply stainless steel texture to the angled lamp arm
	SetShaderTexture("lampMetal");
	SetTextureUVScale(1.0f, 1.0f);

	m_basicMeshes->DrawCylinderMesh();


	/******************************************************************
	 * LAMP SHADE
	 * A cone represents the shade at the end of the lamp arm.
	 ******************************************************************/
	scaleXYZ = glm::vec3(1.4f, 2.0f, 1.4f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = -40.0f;

	positionXYZ = glm::vec3(1.8f, 5.05f, 0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Apply material properties to the lamp shade
	SetShaderMaterial("shadeMaterial");

	// Apply gold texture to the lamp shade
	SetShaderTexture("lampShade");
	SetTextureUVScale(1.0f, 1.0f);

	m_basicMeshes->DrawConeMesh();

	/******************************************************************
 * NOTEBOOK
 * A flat box represents a notebook resting on the desk.
 ******************************************************************/
	positionXYZ = glm::vec3(2.8f, 0.15f, 1.5f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = -15.0f;
	ZrotationDegrees = 0.0f;

	

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Apply a blue notebook cover
	SetShaderMaterial("floorMaterial");
	SetShaderColor(0.15f, 0.25f, 0.55f, 1.0f);

	m_basicMeshes->DrawBoxMesh();

	/******************************************************************
 * COMPUTER MONITOR
 * A rectangular box represents the monitor screen.
 ******************************************************************/
	scaleXYZ = glm::vec3(2.8f, 1.8f, 0.15f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(-3.5f, 2.0f, -1.5f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Apply material and dark screen color
	SetShaderMaterial("metalMaterial");
	SetShaderColor(0.05f, 0.05f, 0.08f, 1.0f);

	// Draw the monitor screen
	m_basicMeshes->DrawBoxMesh();

	/******************************************************************
 * MONITOR STAND
 * A narrow rectangular box supports the monitor screen.
 ******************************************************************/
	scaleXYZ = glm::vec3(0.18f, 1.1f, 0.18f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(-3.5f, 0.65f, -1.5f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderMaterial("metalMaterial");
	SetShaderColor(0.45f, 0.45f, 0.45f, 1.0f);

	m_basicMeshes->DrawBoxMesh();


	/******************************************************************
 * MONITOR BASE
 * A flat rectangular box supports the monitor stand.
 ******************************************************************/
	scaleXYZ = glm::vec3(1.2f, 0.12f, 0.8f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(-3.5f, 0.12f, -1.5f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderMaterial("metalMaterial");
	SetShaderColor(0.35f, 0.35f, 0.35f, 1.0f);

	m_basicMeshes->DrawBoxMesh();

	/******************************************************************
 * PRINTER BODY
 * A rectangular box represents the printer on the wooden desk.
 ******************************************************************/
	scaleXYZ = glm::vec3(2.4f, 0.9f, 1.5f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(-0.8f, 0.5f, 1.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Use a gray color temporarily so we can see the printer
	SetShaderMaterial("metalMaterial");
	SetShaderColor(0.65f, 0.65f, 0.65f, 1.0f);

	// Draw the printer body
	m_basicMeshes->DrawBoxMesh();


	/******************************************************************
 * PRINTER CONTROL PANEL
 * A thin rectangular box represents the top control panel.
 ******************************************************************/
	scaleXYZ = glm::vec3(1.5f, 0.08f, 0.45f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(-0.8f, 1.0f, 1.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Dark gray control panel
	SetShaderMaterial("metalMaterial");
	SetShaderColor(0.25f, 0.25f, 0.25f, 1.0f);

	m_basicMeshes->DrawBoxMesh();

	/******************************************************************
 * COFFEE MUG
 * A cylinder represents the ceramic coffee mug.
 ******************************************************************/
	scaleXYZ = glm::vec3(0.45f, 0.75f, 0.45f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(-2.4f, 0.15f, 1.8f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Apply a light ceramic color
	SetShaderMaterial("metalMaterial");
	SetShaderColor(0.85f, 0.80f, 0.70f, 1.0f);

	// Draw the mug body
	m_basicMeshes->DrawCylinderMesh();

	/******************************************************************
 * SECOND BOOK - GREEN
 ******************************************************************/
	scaleXYZ = glm::vec3(2.2f, 0.15f, 1.6f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = -15.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(2.8f, 0.30f, 1.5f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderMaterial("floorMaterial");
	SetShaderColor(0.35f, 0.45f, 0.15f, 1.0f);

	m_basicMeshes->DrawBoxMesh();

}